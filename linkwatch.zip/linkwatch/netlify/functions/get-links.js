const { Client } = require("pg");
const { getStore } = require("@netlify/blobs");

const PERIOD_HOURS = { "1h": 1, "12h": 12, "1d": 24, "7d": 24 * 7, "1m": 24 * 30, "1y": 24 * 365 };

exports.handler = async (event) => {
  const period = event.queryStringParameters?.period || "1d";
  const hours = PERIOD_HOURS[period] || 24;

  const store = getStore("linkwatch-config");
  const databaseUrl = await store.get("database_url");
  if (!databaseUrl) {
    return { statusCode: 200, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ error: "not configured" }) };
  }

  const client = new Client({
    connectionString: databaseUrl,
    ssl: { rejectUnauthorized: false },
  });

  try {
    await client.connect();
    const { rows } = await client.query(
      `SELECT url FROM links WHERE created_at >= now() - ($1 || ' hours')::interval`,
      [hours]
    );

    const counts = new Map();
    for (const row of rows) {
      counts.set(row.url, (counts.get(row.url) || 0) + 1);
    }

    const entries = [...counts.entries()].sort((a, b) => b[1] - a[1]);
    const total = rows.length;
    const unique = entries.filter(([, c]) => c === 1).length;
    const repeated = entries.filter(([, c]) => c > 1).length;

    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ total, unique, repeated, rows: entries }),
    };
  } catch (err) {
    if (err.code === "42P01") {
      // table not created yet — no messages logged so far
      return {
        statusCode: 200,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ total: 0, unique: 0, repeated: 0, rows: [] }),
      };
    }
    console.error(err);
    return { statusCode: 500, body: JSON.stringify({ error: "DB error" }) };
  } finally {
    await client.end();
  }
};
