const { getStore } = require("@netlify/blobs");

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method not allowed" };
  }

  let body;
  try {
    body = JSON.parse(event.body);
  } catch {
    return { statusCode: 400, body: "Bad JSON" };
  }

  const { databaseUrl, webhookSecret } = body;
  if (!databaseUrl || !webhookSecret) {
    return { statusCode: 400, body: "databaseUrl and webhookSecret are required" };
  }

  try {
    const store = getStore("linkwatch-config");
    await store.set("database_url", databaseUrl);
    await store.set("webhook_secret", webhookSecret);
    return { statusCode: 200, body: "ok" };
  } catch (err) {
    console.error(err);
    return { statusCode: 500, body: "Storage error" };
  }
};
