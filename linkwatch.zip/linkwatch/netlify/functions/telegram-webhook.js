const { Client } = require("pg");
const { getStore } = require("@netlify/blobs");

const URL_RE = /(https?:\/\/[^\s]+)/gi;

async function getConfig() {
  const store = getStore("linkwatch-config");
  const databaseUrl = await store.get("database_url");
  const webhookSecret = await store.get("webhook_secret");
  return { databaseUrl, webhookSecret };
}

async function getClient(databaseUrl) {
  const client = new Client({
    connectionString: databaseUrl,
    ssl: { rejectUnauthorized: false },
  });
  await client.connect();
  return client;
}

async function ensureTable(client) {
  await client.query(`
    CREATE TABLE IF NOT EXISTS links (
      id BIGSERIAL PRIMARY KEY,
      url TEXT NOT NULL,
      chat_id TEXT,
      message_id BIGINT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT now()
    );
  `);
  await client.query(`CREATE INDEX IF NOT EXISTS links_created_at_idx ON links (created_at);`);
}

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method not allowed" };
  }

  const { databaseUrl, webhookSecret } = await getConfig();

  // Verify the request actually came from Telegram
  const secretHeader = event.headers["x-telegram-bot-api-secret-token"];
  if (!webhookSecret || secretHeader !== webhookSecret) {
    return { statusCode: 401, body: "Unauthorized" };
  }
  if (!databaseUrl) {
    return { statusCode: 500, body: "Not configured yet" };
  }

  let update;
  try {
    update = JSON.parse(event.body);
  } catch {
    return { statusCode: 400, body: "Bad JSON" };
  }

  const post = update.channel_post || update.message;
  if (!post) {
    return { statusCode: 200, body: "ignored" };
  }

  const text = post.text || post.caption || "";
  const urls = text.match(URL_RE);
  if (!urls || urls.length === 0) {
    return { statusCode: 200, body: "no links" };
  }

  const chatId = String(post.chat?.id ?? "");
  const messageId = post.message_id ?? null;

  let client;
  try {
    client = await getClient(databaseUrl);
    await ensureTable(client);
    for (const url of urls) {
      await client.query(
        "INSERT INTO links (url, chat_id, message_id) VALUES ($1, $2, $3)",
        [url, chatId, messageId]
      );
    }
    return { statusCode: 200, body: "ok" };
  } catch (err) {
    console.error(err);
    return { statusCode: 500, body: "DB error" };
  } finally {
    if (client) await client.end();
  }
};
